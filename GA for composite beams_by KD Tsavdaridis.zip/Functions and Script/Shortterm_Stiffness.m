function EI0 = Shortterm_Stiffness(EI01, EI02, EI03, EI04)
EI0=(EI01+(EI02/EI03).*EI04).*10.^-4;
end