function [Y A D] = TestMulfiFunc (b, c)

A = b-c;
D = b*c;
Y = A^2+D;

end