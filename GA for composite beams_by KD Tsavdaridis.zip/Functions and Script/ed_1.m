function ed1 = ed_1(Bayspace, Gk)
ed1=Bayspace.*Gk.*10.^-3;
end