% Fitness function for input into GA, Variable x = ha, height of universal
% beam section. this is the second sizing opportunity for a beam section 
% within the EC4 process.
function MplRD = Fullshear_Bending_Resist(Npla, NcSLAB, x, hc, hp,MEd)
MplRD=Npla.*((x(:,1)/2)+hc-(Npla/NcSLAB).*((hc-hp)/2)).*10.^-3;
end