%%Moment Capacity Check for Partial Shear
alphaCHECK1 = alpha_CHECK1(hsc, SCDIA);
alphaCHECK2 = alpha_CHECK2(hsc, SCDIA);
if alphaCHECK1==3;
    alpha=alphaCHECK1;
elseif alphaCHECK1<4;
    alpha=alphaCHECK1;
elseif alphaCHECK1==4;
    alpha=alphaCHECK1;
else alphaCHECK1>4;
    alpha=1;
end
PRdCHECK1 = PRd_CHECK1(alpha, SCDIA, Fck, Ecm, gammaV);
PRdCHECK2 = PRd_CHECK2(Fu, Pi, SCDIA, gammaV);
PRd=min(PRdCHECK1,PRdCHECK2);
KtCalc = Kt_influence(b1, b2, hp, hsc);
Kt=min(KtCalc,KtMAX);
PRdKt = PRd_Reduced(PRd, Kt);
NoHalfSpan = Shearstuds_per_Halfspan(Beamspan, ha, STUDspace); %Beamspan = x(16) if L is variable
Rq = Degree_Shear_Connection(PRdKt, NoHalfSpan);
eta = eta_check(Rq, Npla);
if eta<1;
    "Partial Shear Connection";
elseif eta==1;
    "Full Shear Connection";
else eta>1;
    "Full Shear Connection";
end
MinShearCalc = Minimum_Shear_Connection(Fy, Leff);
if MinShearCalc<eta;
    "pass";
elseif MinShear<eta;
    "pass";
else eta<MinShear;
    "fail";
end
MplaRD = Initial_Partialshear_Moment(Fy, WPLyy); %WPLyy = x(10) if Steel Section is Variable
MRd = Partialshear_Bending_Resist(MplaRD, MplRD, eta)
%Check MEd/MRd <1%
if MEd/MRd<1
    "Moment capacity is satifactory";
else MEd/MRd>1
    "Fail"
end
