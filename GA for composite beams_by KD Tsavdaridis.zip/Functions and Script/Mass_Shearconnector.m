function Masssc = Mass_Shearconnector(Kgsc, Noconnectors)
Masssc=Kgsc.*Noconnectors;
end