function NoHalfSpan = Shearstuds_per_Halfspan(Beamspan, ha, STUDspace)
NoHalfSpan=floor(((Beamspan/2)-(ha/2))/STUDspace);
end