%Part 1 - Actions on the Structure
clc
% Determination of Combined Actions upon Structure, Design Bending Moment
% and Design Shear Force
Fd1 = Combined_force(Gk, gammaG, Qk, gammaQ);
Floorarea = Floor_area(Beamspan, Bayspace);
Fd = Combined_action(Fd1, Floorarea);
MEd = Design_moment(Fd, Beamspan)
VEd = Design_shear(Fd)
%
%
%
% Part 2 - ULS Design Checks
% Moment Capacity check for full shear connection
FcCOMP = Conc_Comp_Strength(Fck,alphaCC,gammaC);
Leff = Effective_Beam_Length(Beamspan);% Beamspan = x(16) if length is variable
bei = b_effective_i(Leff);
beff = b_effective(Rowspace,bei);
NcSLAB = Slab_Comp_Resist(FcCOMP, beff, hc, hp); %hc = x(15) if slab thickness is variable
Npla = Slab_Tens_Resist(Fy, Aa, gammaM0); %Aa = x(14) if steel section is variable
% 
%Check Neutral axis is within Concrete flange%
if Npla<NcSLAB
    "Neutral Axis is Within Concrete Flange, Continue"
else
    "fail"
end
%
MplRD = Fullshear_Bending_Resist(Npla, NcSLAB, ha, hc, hp) %ha = x(2) if steel section is variable, hc = x(15) if slab thickness is variable
%Check Moment Capcity%
if MEd/MplRD<1
    "Moment capacity is satifactory"
else
    "fail"
end