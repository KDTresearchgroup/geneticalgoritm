function PRdCHECK2 = PRd_CHECK2(Fu, Pi, SCDIA, gammaV)
PRdCHECK2=(0.8.*Fu.*(pi.*SCDIA.^2/4))/gammaV.*10.^-3;
end