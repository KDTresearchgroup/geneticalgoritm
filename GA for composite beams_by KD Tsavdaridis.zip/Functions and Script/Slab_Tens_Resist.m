% Fitness function for input into GA, Variable X = Aa, Cross sectional area
% of the universal beam section. this is the first sizing opportunity within
% the EC4 process. Further optimising for ha, gives further refinement to
% the process. 
function Npla = GA_Slab_Tens_Resist(Fy, x, gammaM0)
Npla=((Fy.*x(:,1).*10.^2)/gammaM0).*10.^-3;
Fy = 275
gammaM0 = 1
end