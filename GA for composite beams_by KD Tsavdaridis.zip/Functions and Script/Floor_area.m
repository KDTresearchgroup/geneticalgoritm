function Floorarea = Floor_area(Beamspan, Bayspace)
Floorarea = (Beamspan.*Bayspace).*10.^-6;
end