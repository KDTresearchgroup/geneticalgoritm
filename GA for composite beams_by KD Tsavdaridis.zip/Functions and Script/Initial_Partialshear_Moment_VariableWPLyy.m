function MplaRD = Initial_Partialshear_Moment(Fy, x)
MplaRD=Fy.*x(10).*10.^-3;
end