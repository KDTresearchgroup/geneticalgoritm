function Fd = Combined_action(Fd1, Floorarea)
Fd = Fd1.*Floorarea;
end