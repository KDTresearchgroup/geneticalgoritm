function Leff = Effective_Beam_Length_VariableL(x)
Leff=(x(16)/1).*10.^-3;
end
