% Moment Capacity with Full Shear Optimisation for MplRD with variable ha
%
rng default
% 
options = optimoptions (@ga, "UseVectorized", true);
VFitFcn = @(x)GA_Fullshear_Bending_Resist(Npla,NcSLAB,x,hc,hp)
ConsFcn = MplRD_Constraints;
nvars = 1
lb = [127]
ub = [1056] 
[x,fval] = ga(VFitFcn,nvars,[],[],[],[],lb,ub,ConsFcn,options);
x
fval
MplRD = fval