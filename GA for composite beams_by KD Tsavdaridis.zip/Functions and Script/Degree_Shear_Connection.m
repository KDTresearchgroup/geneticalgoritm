function Rq = Degree_Shear_Connection(PRdKt, NoHalfSpan)
Rq=PRdKt.*NoHalfSpan;
end