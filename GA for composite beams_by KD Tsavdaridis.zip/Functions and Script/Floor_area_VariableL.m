function Floorarea = Floor_area(x, Bayspace)
Floorarea = (x15.*Bayspace).*10.^-6;
end