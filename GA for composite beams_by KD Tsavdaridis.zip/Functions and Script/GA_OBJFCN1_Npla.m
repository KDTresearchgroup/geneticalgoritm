% Slab Tension Resistance Optimisation for Npla with variable Aa
%
rng default
% Define Constant Values below, or import data for inputs
options = optimoptions (@ga,"UseVectorized", true);
VFitFcn = @(x)GA_Slab_Tens_Resist(x,Fy,gammaM0)
nvars = 1
lb = [16.5]
ub = [744]
[x,fval] = ga(VFitFcn,nvars,[],[],[],[],lb,ub,[],options);
x
fval
Fy = 275
gammaM0 = 0
