function Npla = Slab_Tens_Resist(Fy, x, gammaM0)
Npla=((Fy.*x(14).*10.^2)/gammaM0).*10.^-3;
end