function beff=b_effective(Rowspace, bei)
beff=Rowspace+(2.*bei);
end