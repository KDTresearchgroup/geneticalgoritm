function VRcomp = Concrete_strut(V, FcCOMP, Y, Z)
VRcomp=V.*FcCOMP.*Y.*Z.*2;
end