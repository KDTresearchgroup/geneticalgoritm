function PRdKt = PRd_Reduced(PRd, Kt)
PRdKt=PRd.*Kt;
end