function MplaRD = Initial_Partialshear_Moment(Fy, WPLyy)
MplaRD=Fy.*WPLyy.*10.^-3;
end