function VEd = Design_shear(Fd)
VEd = (Fd/2);
end