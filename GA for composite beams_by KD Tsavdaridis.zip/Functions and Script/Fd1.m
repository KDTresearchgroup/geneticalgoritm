function Fd1 = Fd1(p)
Fd1 = (p(;,21).*p(;,23))+(p(;,22).*p(;,24))
end