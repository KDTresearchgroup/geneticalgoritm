function EIs = Shrinkage_Stiffness(EIs1, EIs2, EIs3, EIs4)
EIs=(EIs1+(EIs2/EIs3).*EIs4).*10.^-4;
end