function EcontC = Energy_Concrete(Massc, EfactorC)
EcontC=Massc.*EfactorC;
end