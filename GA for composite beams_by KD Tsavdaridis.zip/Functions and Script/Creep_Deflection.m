function d3 = Creep_Deflection(ed3, Beamspan, EIp, EI0)
d3=((5/384).*(((ed3.*(Beamspan.*10.^-3).^4))/EIp).*10.^3)-((5/384).*(((ed3.*(Beamspan.*10.^-3).^4))/EI0).*10.^3);
end