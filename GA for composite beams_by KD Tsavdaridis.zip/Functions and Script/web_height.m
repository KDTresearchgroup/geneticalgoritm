function hw = web_height(ha, tf)
hw=ha-(2.*tf);
end