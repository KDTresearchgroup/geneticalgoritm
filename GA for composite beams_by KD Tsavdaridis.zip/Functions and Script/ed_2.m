function ed2 = ed_2(Bayspace, Psi1, Qk)
ed2=Bayspace.*Psi1.*Qk.*10.^-3;
end