function MplRD = Fullshear_Bending_Resist(Npla, NcSLAB, ha, x, hp)
MplRD=Npla.*(ha/2)+x(15)-(Npla/NcSLAB).*((hc-hp)/2)).*10.^-3;
end