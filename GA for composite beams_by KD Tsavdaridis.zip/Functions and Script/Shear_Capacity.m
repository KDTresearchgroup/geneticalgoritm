function VplRD = Shear_Capacity(Av, Fy, gammaM0)
VplRD=(Av.*(Fy/3.^0.5))/gammaM0.*10.^-3;
end