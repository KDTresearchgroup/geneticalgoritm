%
% Part 1 - Actions upon the Structure
clc
% Determination of Combined Actions upon Structure, Design Bending Moment
% and Design Shear Force
Fd1 = Combined_force(Gk, gammaG, Qk, gammaQ);
Floorarea = Floor_area(Beamspan, Bayspace);
Fd = Combined_action(Fd1, Floorarea);
MEd = Design_moment(Fd, Beamspan)%Beamspan = x(16) if L is variable%
VEd = Design_shear(Fd)
%
% Part 2 - Ultimate limit state verification
% Moment Capacity check for full shear connection
FcCOMP = Conc_Comp_Strength(Fck,alphaCC,gammaC);
Leff = Effective_Beam_Length(Beamspan);% Beamspan = x(16) if length is variable
bei = b_effective_i(Leff);
beff = b_effective(Rowspace,bei);
NcSLAB = Slab_Comp_Resist(FcCOMP, beff, hc); %hc = x(15) if slab thickness is variable
Npla = Slab_Tens_Resist(Fy, Aa, gammaM0); %Aa = x(14) if steel section is variable
%
%Check Neutral axis is within Concrete flange%
if Npla<NcSLAB
    "Neutral Axis is Within Concrete Flange, Continue"
else
    "fail"
end
%
MplRD = Fullshear_Bending_Resist(Npla, NcSLAB, ha, hc, dslab) %ha = x(2) if steel section is variable, hc = x(15) if slab thickness is variable
%Check Moment Capcity%
if MEd/MplRD<1
    "Moment capacity is satifactory"
else
    "fail"
end
%
% Moment Capacity Check for Partial Shear
alphaCHECK1 = alpha_CHECK1(hsc, SCDIA);
alphaCHECK2 = alpha_CHECK2(hsc, SCDIA);
if alphaCHECK1==3;
    alpha=alphaCHECK1;
elseif alphaCHECK1<4;
    alpha=alphaCHECK1;
elseif alphaCHECK1==4;
    alpha=alphaCHECK1;
else alphaCHECK1>4;
    alpha=1;
end
PRdCHECK1 = PRd_CHECK1(alpha, SCDIA, Fck, Ecm, gammaV);
PRdCHECK2 = PRd_CHECK2(Fu, Pi, SCDIA, gammaV);
PRd=min(PRdCHECK1,PRdCHECK2);
KtCalc = Kt_influence(b1, b2, hp, hsc);
Kt=min(KtCalc,KtMAX);
PRdKt = PRd_Reduced(PRd, Kt);
NoHalfSpan = Shearstuds_per_Halfspan(Beamspan, ha, STUDspace); %Beamspan = x(16) if L is variable
Rq = Degree_Shear_Connection(PRdKt, NoHalfSpan);
eta = eta_check(Rq, Npla);
if eta<1;
    "Partial Shear Connection";
elseif eta==1;
    "Full Shear Connection";
else eta>1;
    "Full Shear Connection";
end
MinShearCalc = Minimum_Shear_Connection(Fy, Leff);
if MinShearCalc<eta;
    "pass";
elseif MinShear<eta;
    "pass";
else eta<MinShear;
    "fail";
end
MplaRD = Initial_Partialshear_Moment(Fy, WPLyy); %WPLyy = x(10) if Steel Section is Variable
MRd = Partialshear_Bending_Resist(MplaRD, MplRD, eta)
% Check MEd/MRd <1%
if MEd/MRd<1
    "Moment capacity is satifactory"
else MEd/MRd>1
    "Fail"
end
% Shear Buckling of the uncased web
epsilon = epsilon_calc(Fy);
hw = web_height(ha, tf);
hwtw = webheight_webthickness(hw, tw);
if hwtw<(72/etaBUCKLE).*epsilon;
    "Buckling Capacity Satisfactory"
else hwtw>(72/etaBUCKLE).*epsilon;
    "fail"
end;
% Resistance to Vertical Shear
Av1 = Shear_Area1(Aa, ba, tf, tw, r);
Av2 = Shear_Area2(hw, tw);
Av=max(Av1,Av2);
VplRD = Shear_Capacity(Av, Fy, gammaM0)
% Check VEd/VplRD <1%
if VEd/VplRD<1
    "Shear Capacity Satisfactory"
else VEd/VplRD>1
    "fail"
end
% Design of Transverse Reinforcement
Fyd = Rebar_Yield_Strength(Fyk, gammaS);
VEdREBAR = Rebar_Shear_Capacity(Rq, hc, hp, Beamspan);
X=cot(Theta);
AreaRebarReq = Rebar_Required(VEdREBAR, hc, hp, Fyd, X);
if AreaRebarReq<142
    AreaRebar=142
elseif AreaRebarReq<193
    AreaRebar=193
elseif AreaRebarReq<252
    AreaRebar=252
else AreaRebarReq<393
    AreaRebar=393
end
if AreaRebar==142
    RebarMass=2.22
elseif AreaRebar==193
    RebarMass=3.02
elseif AreaRebar==252
    RebarMass=3.95
else AreaRebar=393
    RebarMass=6.16
end
% Crushing of Concrete Strut
V=0.6.*(1-(Fck/250));
Y=sin(Theta);
Z=cos(Theta);
VRcomp = Concrete_strut(V, FcCOMP, Y, Z);
if VEdREBAR/VRcomp<1
    "Pass"
else VEdREBAR/VRcomp>1;
    "Fail"
end
% Part 3 - Serviceability limit state verification
h0=2.*hc;
% Short Term Effective Flexural Stiffness
Ic = Concrete_SMA(beff, hc);
Ac = Concrete_Area(beff, hc);
a = Concrete_Smalla(ha, hp, hc);
E0 = Short_E(Ecm, ncshort);
EI01=(Ea.*Iyy)+(E0.*Ic);
EI02=Ea.*Aa.*E0.*Ac;
EI03=(Ea.*Aa)+(E0.*Ac);
EI04=a.^2;
EI0 = Shortterm_Stiffness(EI01, EI02, EI03, EI04);
% Permanent Effective Flexural Stiffness
ncperm = nc_perm(phi28);
Ep = Permanent_E(Ecm, ncperm);
EIp1=(Ea.*Iyy)+(Ep.*Ic);
EIp2=Ea.*Aa.*Ep.*Ac;
EIp3=(Ea.*Aa)+(Ep.*Ac);
EIp4=a.^2;
EIp = Permanent_Stiffness(EIp1, EIp2, EIp3, EIp4);
% Shrinkage Effective Flexural Stiffness
ncshrink = nc_shrinkage(phi1);
Es = Shrinkage_E(Ecm, ncshrink);
EIs1=(Ea.*Iyy)+(Es.*Ic);
EIs2=Ea.*Aa.*Es.*Ac;
EIs3=(Ea.*Aa)+(Es.*Ac);
EIs4=a.^2;
EIs = Shrinkage_Stiffness(EIs1, EIs2, EIs3, EIs4);
% Deflection Due to Permanent Loading
ed1 = ed_1(Bayspace, Gk);
d1 = Permanent_Deflection(ed1, Beamspan, EI0);
% Deflection Due to Variable Loading
ed2 = ed_2(Bayspace, Psi1, Qk);
d2 = Variable_Deflection(ed2, Beamspan, EI0);
% Deflection Due to Creep
ed3 = ed_3(Gk, Psi2, Bayspace, Qk);
d3 = Creep_Deflection(ed3, Beamspan, EIp, EI0);
% Deflection Due to Shrinkage
Ncs = nc_shrinkagestress(epsilonsc, Es, Ac);
ac = a_c(Ea, Aa, Es, Ac, a);
Mcs = M_cs(Ncs, ac);
d4 = Shrinkage_Deflection(Mcs, Beamspan, EIs);
% Total Deflection
dTOTAL = Total_Deflection(d1, d2, d3, d4)
if dTOTAL<Beamspan/250
    "Pass"
else dTOTAL>Beamspan/250
    "Fail"
end
% Part 4 - Life Cycle Energy Analysis
% Component Mass Calculations
% Steel Section
Massa = Mass_Steel(Mass, Beamspan);
% Shear Connectors
AshankDIA=(pi.*(SCDIA.*10.^-3).^2)/4;
AheadDIA=(pi.*(SHDIA.*10.^-3).^2)/4;
Vshank=(AshankDIA.*Lshank).*10.^-3;
Vhead=(AheadDIA.*Lhead).*10.^-3;
Vsc=Vshank+Vhead;
Kgsc=Vsc.*Densitysc;
Masssc = Mass_Shearconnector(Kgsc, Noconnectors);
% Mass Profiled Sheeting
Massps = Mass_Profiledsheet (Floorarea, Densityps);
% Mass Concrete
Averagehc=(hc+(hc-hp))/2.*10.^-3;
Vconc=Floorarea.*Averagehc;
Massc = Mass_Concrete(Vconc, Densityconc);
% Mass Rebar
Rebarsheets=Floorarea/Rebarsheetarea;
Massr = Mass_Rebar(Rebarsheets, Densityr);
% Component Embodied Energy Calculations
EcontA = Energy_Steel(Massa, EfactorA)
EcontSC = Energy_Shearconnectors(Masssc, EfactorSC)
EcontPS = Energy_Profiledsheet(Massps, EfactorPS)
EcontC = Energy_Concrete(Massc, EfactorC)
EcontR = Energy_Rebar(Massr, EfactorR)
% Total Embodied Energy
EEi = Total_Embodied_Energy(EcontA, EcontSC, EcontPS, EcontC, EcontR)