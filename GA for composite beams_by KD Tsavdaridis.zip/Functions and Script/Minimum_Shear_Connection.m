function MinShearCalc = Minimum_Shear_Connection(Fy, Leff)
MinShearCalc=1-(355/Fy).*(0.75-0.03.*Leff);
end