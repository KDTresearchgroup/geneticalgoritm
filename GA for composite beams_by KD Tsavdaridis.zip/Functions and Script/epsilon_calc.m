function epsilon = epsilon_calc(Fy)
epsilon=(235/Fy).^0.5;
end