function ed3 = ed_3(Gk, Psi2, Bayspace, Qk)
ed3=Bayspace.*(Gk+(Psi2.*Qk)).*10.^-3;
end