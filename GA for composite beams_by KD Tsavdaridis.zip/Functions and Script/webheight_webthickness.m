function hwtw = webheight_webthickness(hw, tw)
hwtw=hw/tw;
end