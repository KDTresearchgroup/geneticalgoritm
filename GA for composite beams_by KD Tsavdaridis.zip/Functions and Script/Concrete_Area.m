function Ac = Concrete_Area(beff, hc)
Ac=(beff.*(hc.*10.^-1)).*10.^2;
end