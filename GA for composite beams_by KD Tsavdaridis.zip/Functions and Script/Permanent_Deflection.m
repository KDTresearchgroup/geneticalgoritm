function d1 = Permanent_Deflection(ed1, Beamspan, EI0)
d1=(5/384).*(((ed1.*(Beamspan.*10.^-3).^4))/EI0).*10.^3;
end