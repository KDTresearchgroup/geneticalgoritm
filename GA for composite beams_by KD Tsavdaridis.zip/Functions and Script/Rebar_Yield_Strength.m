function Fyd = Rebar_Yield_Strength(Fyk, gammaS)
Fyd=Fyk/gammaS;
end