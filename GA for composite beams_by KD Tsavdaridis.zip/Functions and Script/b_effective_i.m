function bei = b_effective_i(Leff)
bei=Leff/8;
end