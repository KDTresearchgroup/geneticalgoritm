function MplRD = Fullshear_Bending_Resist(Npla, NcSLAB, x, hc, hp)
MplRD=Npla.*((x(2)/2)+hc-(Npla/NcSLAB).*((hc-hp)/2)).*10.^-3;
end