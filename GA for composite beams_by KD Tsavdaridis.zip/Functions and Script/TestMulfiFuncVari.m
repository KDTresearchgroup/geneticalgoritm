function [Y A D] = TestMulfiFunc (x)

A = x(1)-x(2);
D = x(1)*x(2);
Y = A^2+D;

end