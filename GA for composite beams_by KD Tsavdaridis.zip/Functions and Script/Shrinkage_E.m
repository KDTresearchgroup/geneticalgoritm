function Es = Shrinkage_E(Ecm, ncshrink)
Es=(Ecm/ncshrink).*10.^-1;
end