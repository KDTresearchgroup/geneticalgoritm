function EcontSC = Energy_Shearconnectors(Masssc, EfactorSC)
EcontSC=Masssc.*EfactorSC;
end