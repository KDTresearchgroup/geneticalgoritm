function ncshrink = nc_shrinkage(phi1)
ncshrink=1+(1.1.*phi1);
end