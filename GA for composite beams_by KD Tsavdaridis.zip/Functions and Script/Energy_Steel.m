function EcontA = Energy_Steel(Massa, EfactorA)
EcontA=Massa.*EfactorA;
end