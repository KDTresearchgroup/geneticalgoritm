function FcCOMP = Conc_Comp_Strength(Fck, alphaCC, gammaC)
FcCOMP=(Fck.*alphaCC)/gammaC;
end