%Shear Buckling of the uncased web
epsilon = epsilon_calc(Fy);
hw = web_height(ha, tf);
hwtw = webheight_webthickness(hw, tw);
if hwtw<(72/etaBUCKLE).*epsilon;
    "Buckling Capacity Satisfactory"
else hwtw>(72/etaBUCKLE).*epsilon;
    "fail"
end;
%Resistance to Vertical Shear
Av1 = Shear_Area1(Aa, ba, tf, tw, r);
Av2 = Shear_Area2(hw, tw);
Av=max(Av1,Av2);
VplRD = Shear_Capacity(Av, Fy, gammaM0)
%Check VEd/VplRD <1%
if VEd/VplRD<1
    "Shear Capacity Satisfactory"
else VEd/VplRD>1
    "fail"
end