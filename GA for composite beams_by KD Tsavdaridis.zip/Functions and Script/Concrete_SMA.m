function Ic = Concrete_SMA(beff, hc)
Ic=((beff.*10.^3.*(hc.^3))/12).*10.^-4;
end