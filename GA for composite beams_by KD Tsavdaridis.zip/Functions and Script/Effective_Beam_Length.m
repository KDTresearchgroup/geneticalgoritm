function Leff = Effective_Beam_Length(Beamspan)
Leff=(Beamspan/1).*10.^-3;
end
