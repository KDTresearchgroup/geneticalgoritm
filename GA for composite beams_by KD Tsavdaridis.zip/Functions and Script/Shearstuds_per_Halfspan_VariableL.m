function NoHalfSpan = Shearstuds_per_Halfspan(x, ha, STUDspace)
NoHalfSpan=floor(((x(15)/2)-(ha/2))/STUDspace)
end