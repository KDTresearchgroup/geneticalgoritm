function NcSLAB = Slab_Comp_Resist(FcComp, beff, x, hp)
NcSLAB=(FcCOMP.*beff).*(x(15)-hp);
end