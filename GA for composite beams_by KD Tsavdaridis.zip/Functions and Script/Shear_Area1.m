function Av1 = Shear_Area1(Aa, ba, tf, tw, r)
Av1=(Aa.*10.^2)-(2.*ba.*tf)+tf.*(tw+(2.*r));
end