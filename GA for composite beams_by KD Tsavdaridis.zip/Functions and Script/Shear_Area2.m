function Av2 = Shear_Area2(hw, tw)
Av2=1.*hw.*tw;
end