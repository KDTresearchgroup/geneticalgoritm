function Ep = Permanent_E(Ecm, ncperm)
Ep=(Ecm/ncperm).*10.^-1;
end