function ncperm = nc_perm(phi28)
ncperm=1+(1.1.*phi28);
end