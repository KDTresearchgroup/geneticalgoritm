function [c, c_eq] = MplRD_Constraints(MplRD, MEd)
c = MplRd
c_eq = []
