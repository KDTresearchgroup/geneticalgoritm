function Massr = Mass_Rebar(Rebarsheets, Densityr)
Massr=Rebarsheets.*Densityr;
end