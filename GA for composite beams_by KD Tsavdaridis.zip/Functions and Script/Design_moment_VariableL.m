function MEd = Design_moment(Fd, x)
MEd = ((Fd.*x(16))/8).*10.^-3;
end