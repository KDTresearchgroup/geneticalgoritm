function EcontPS = Energy_Profiledsheet(Massps, EfactorPS)
EcontPS=Massps.*EfactorPS;
end