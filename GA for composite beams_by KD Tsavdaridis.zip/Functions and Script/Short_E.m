function E0 = Short_E(Ecm,ncshort)
E0=(Ecm/ncshort).*10.^-1;
end