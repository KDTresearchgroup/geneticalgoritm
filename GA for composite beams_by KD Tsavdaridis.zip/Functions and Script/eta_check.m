function eta = eta_check(Rq, Npla)
eta=Rq/Npla;
end