function EIp = Permanent_Stiffness(EIp1, EIp2, EIp3, EIp4)
EIp=(EIp1+(EIp2/EIp3).*EIp4).*10.^-4;
end