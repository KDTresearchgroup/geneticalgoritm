%Design of Transverse Reinforcement
Fyd = Rebar_Yield_Strength(Fyk, gammaS);
VEdREBAR = Rebar_Shear_Capacity(Rq, hc, hp, Beamspan);
X=cot(Theta);
AreaRebarReq = Rebar_Required(VEdREBAR, hc, hp, Fyd, X);
if AreaRebarReq<142
    AreaRebar=142
elseif AreaRebarReq<193
    AreaRebar=193
elseif AreaRebarReq<252
    AreaRebar=252
else AreaRebarReq<393
    AreaRebar=393
end
if AreaRebar==142
    RebarMass=2.22
elseif AreaRebar==193
    RebarMass=3.02
elseif AreaRebar==252
    RebarMass=3.95
else AreaRebar=393
    RebarMass=6.16
end
%Crushing of Concrete Strut
V=0.6.*(1-(Fck/250));
Y=sin(Theta);
Z=cos(Theta);
VRcomp = Concrete_strut(V, FcCOMP, Y, Z);
if VEdREBAR/VRcomp<1
    "Pass"
else VEdREBAR/VRcomp>1;
    "Fail"
end