function KtCalc = Kt_influence(b1,b2,hp,hsc)
KtCalc=(0.7/(1.^0.5)).*(((b1+b2)/2)/hp).*((hsc/hp)-1);
end