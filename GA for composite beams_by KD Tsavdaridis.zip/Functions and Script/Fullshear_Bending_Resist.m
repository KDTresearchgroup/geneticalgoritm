function MplRD = Fullshear_Bending_Resist(Npla, NcSLAB, ha, hc, hp)
MplRD=Npla.*((ha/2)+hc-(Npla/NcSLAB).*((hc-hp)/2)).*10.^-3;
end