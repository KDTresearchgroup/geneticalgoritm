function Fd1 = Fd1(Gk, gammaG, Qk, gammaQ)
Fd1 = (Gk.*gammaG)+(Qk.*gammaQ);
end