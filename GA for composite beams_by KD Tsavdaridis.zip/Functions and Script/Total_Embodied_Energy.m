function EEi = Total_Embodied_Energy(EcontA, EcontSC, EcontPS, EcontC, EcontR)
EEi=EcontA+EcontSC+EcontPS+EcontC+EcontR;
end