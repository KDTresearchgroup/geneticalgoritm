%%% Part 4 - Life Cycle Energy Analysis
% Component Mass Calculations
% Steel Section
Massa = Mass_Steel(Mass, Beamspan);
% Shear Connectors
AshankDIA=(pi.*(SCDIA.*10.^-3).^2)/4;
AheadDIA=(pi.*(SHDIA.*10.^-3).^2)/4;
Vshank=(AshankDIA.*Lshank).*10.^-3;
Vhead=(AheadDIA.*Lhead).*10.^-3;
Vsc=Vshank+Vhead;
Kgsc=Vsc.*Densitysc;
Masssc = Mass_Shearconnector(Kgsc, Noconnectors);
% Mass Profiled Sheeting
Massps = Mass_Profiledsheet (Floorarea, Densityps);
% Mass Concrete
Averagehc=(hc+(hc-hp))/2.*10.^-3;
Vconc=Floorarea.*Averagehc;
Massc = Mass_Concrete(Vconc, Densityconc);
% Mass Rebar
Rebarsheets=Floorarea/Rebarsheetarea;
Massr = Mass_Rebar(Rebarsheets, Densityr);
% Component Embodied Energy Calculations
EcontA = Energy_Steel(Massa, EfactorA)
EcontSC = Energy_Shearconnectors(Masssc, EfactorSC)
EcontPS = Energy_Profiledsheet(Massps, EfactorPS)
EcontC = Energy_Concrete(Massc, EfactorC)
EcontR = Energy_Rebar(Massr, EfactorR)
% Total Embodied Energy
EEi = Total_Embodied_Energy(EcontA, EcontSC, EcontPS, EcontC, EcontR)
