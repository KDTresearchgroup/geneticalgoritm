function PRdCHECK1 = PRd_CHECK1(alpha, SCDIA, Fck, Ecm, gammaV)
PRdCHECK1=(0.29.*alpha.*SCDIA.^2.*(Fck.*Ecm).^0.5)/gammaV.*10.^-3;
end