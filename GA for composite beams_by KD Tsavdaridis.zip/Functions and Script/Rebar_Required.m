function AreaRebarReq = Rebar_Required(VEdREBAR, hc, hp, Fyd,X)
AreaRebarReq=(VEdREBAR.*(hc-hp))/(Fyd.*X).*10.^2;
end