function MEd = Design_moment(Fd, Beamspan)
MEd = ((Fd.*Beamspan)/8).*10.^-3;
end