function d4 = Shrinkage_Deflection(Mcs, Beamspan, EIs)
d4=(1/8).*((Mcs.*(Beamspan.*10^-3).^2)/EIs).*10.^3;
end