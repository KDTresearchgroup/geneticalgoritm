function Mcs = M_cs(Ncs, ac)
Mcs=Ncs.*(ac/100);
end