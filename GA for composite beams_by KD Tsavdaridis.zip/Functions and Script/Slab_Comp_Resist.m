function NcSLAB = Slab_Comp_Resist(FcCOMP, beff, hc,)
NcSLAB=(FcCOMP.*beff).*hc;
end