%Part 1, Actions Upon the structure%
%Fd - Combined ULS Action%
Fd1=(Gk.*gammaG)+(Qk.*gammaQ)
Floorarea=(Beamspan.*Bayspace).*10.^-6
Fd=Fd1.*Floorarea
%MEd - Design Moment%
MEd=((Fd.*Beamspan)/8).*10.^-3
%VEd - Design Shear%
VEd=(Fd/2)
%
%Part 2, ULS Checks%
%Moment capacity for full shear connection%
%FcCOMP - Compressive Strength of Concrete%
FcCOMP=(Fck.*alphaCC)/gammaC
%Compression Resistance of Slab NcSLAB. First calculate effective Length
%(Leff), second calculate bei, third beff, then finally NcSLAB%
Leff=(Beamspan/1).*10.^-3
bei=Leff/8
beff=Rowspace+(2.*bei)
NcSLAB=(FcCOMP.*beff).*(hc-hp)
%Npla - Tensile Resistance of Slab Npla%
Npla=((Fy.*Aa.*10.^2)/gammaM0).*10.^-3
%Check Neutral axis is within Concrete flange%
if Npla<NcSLAB
    "Neutral Axis is Within Concrete Flange, Continue"
else
    "fail"
end
%MplRD - Design Bending Resistance with Full Shear Connection%
MplRD=Npla.*((ha/2)+hc-(Npla/NcSLAB).*((hc-hp)/2)).*10.^-3
%Check Moment Capcity%
if MEd/MplRD<1
    "Moment capacity is satifactory"
else
    "fail"
end
%PRd - Shear Connection Resistance%
%First, determine value for alpha%
alphaCHECK1=hsc/SCDIA
alphaCHECK2=0.2.*((hsc/SCDIA)+1)
if alphaCHECK1==3
    alpha=alphaCHECK1
elseif alphaCHECK1<4
    alpha=alphaCHECK1
elseif alphaCHECK1==4
    alpha=alphaCHECK1
else alphaCHECK1>4
    alpha=1
end
%PRd is minimum of PRdCHECK1 and PRdCHECK2%
PRdCHECK1=(0.29.*alpha.*SCDIA.^2.*(Fck.*Ecm).^0.5)/gammaV.*10.^-3
PRdCHECK2=(0.8.*Fu.*(pi.*SCDIA.^2/4))/gammaV.*10.^-3
PRd=min(PRdCHECK1,PRdCHECK2)
%Influence on Deck Shape is minimum of KtCalc and KtMAX%
KtMAX=1
KtCalc=(0.7/(1.^0.5)).*(((b1+b2)/2)/hp).*((hsc/hp)-1)
Kt=min(KtCalc,KtMAX)
PRdKt=PRd.*Kt
%Number of shear studs in a half span%
NoHalfSpan=floor(((Beamspan/2)-(ha/2))/STUDspace)
%Rq - degree of shear connection%
Rq=PRdKt.*NoHalfSpan
eta=Rq/Npla
if eta<1
    "Partial Shear Connection"
elseif eta==1
    "Full Shear Connection"
else eta>1
    "Full Shear Connection"
end
MinShearCalc=1-(355/Fy).*(0.75-0.03.*Leff)
if MinShearCalc<eta
    "pass"
elseif MinShear<eta
    "pass"
else eta<MinShear
    "fail"
end
%MplaRD - Design Moment Resistance with Partial Shear%
MplaRD=Fy.*WPLyy.*10.^-3
MRd=MplaRD+(MplRD-MplaRD).*eta
%Check MEd/MRd <1%
if MEd/MRd<1
    "Pass";
else MEd/MRd>1
    "Fail"
end
%Shear Buckling of the uncased web%
epsilon=(235/Fy).^0.5
etaBUCKLE=1
(72/etaBUCKLE).*epsilon
hw=ha-(2.*tf)
hwtw=hw/tw
if hwtw<(72/etaBUCKLE).*epsilon
    "pass"
else hwtw>(72/etaBUCKLE).*epsilon
    "fail"
end
%VplRD - Resitance to Vertical Shear%
Av1=(Aa.*10.^2)-(2.*ba.*tf)+tf.*(tw+(2.*r))
Av2=1.*hw.*tw
Av=max(Av1,Av2)
VplRD=(Av.*(Fy/3.^0.5))/gammaM0.*10.^-3
%Check VEd/VplRD <1%
if VEd/VplRD<1
    "pass"
else VEd/VplRD>1
    "fail"
end
%Design of Transverse Reinforcement%
Fyd=Fyk/gammaS
VEdREBAR=(Rq.*1000)/(2.*(hc-hp).*(Beamspan/2))
Theta=26.5
X=cot(Theta)
AreaRebarReq=(VEdREBAR.*(hc-hp))/(Fyd.*X).*10.^2
if AreaRebarReq<142
    AreaRebar=142
elseif AreaRebarReq<193
    AreaRebar=193
elseif AreaRebarReq<252
    AreaRebar=252
else AreaRebarReq<393
    AreaRebar=393
end
if AreaRebar==142
    RebarMass=2.22
elseif AreaRebar==193
    RebarMass=3.02
elseif AreaRebar==252
    RebarMass=3.95
else AreaRebar=393
    RebarMass=6.16
end
%Crushing of Concrete Compression Strut%
V=0.6.*(1-(Fck/250))
Y=sin(Theta)
Z=cos(Theta)
VRcomp=V.*FcCOMP.*Y.*Z.*2
%Check VEdREBAR/VcCOMP<1%
if VEdREBAR/VRcomp<1
    "Pass"
else VEdREBAR/VRcomp>1;
    "Fail"
end
%
%Part 3, SLS Checks%
%For RH = 50% and Cement class = N%
phi1=4.8
phi28=2.5
h0=2.*hc
%EI0 - Short Term Effective Flexural Stiffness%
Ic=((beff.*10.^3.*(hc.^3))/12).*10.^-4
Ac=(beff.*(hc.*10.^-1)).*10.^2
ncshort=1
a=((ha/2)+hp+(hc/2)).*10.^-1
E0=(Ecm/ncshort).*10.^-1
EI01=(Ea.*Iyy)+(E0.*Ic)
EI02=Ea.*Aa.*E0.*Ac
EI03=(Ea.*Aa)+(E0.*Ac)
EI04=a.^2
EI0=(EI01+(EI02/EI03).*EI04).*10.^-4
%EIp - Permanent Effective Flexural Stiffness%
ncperm=1+(1.1.*phi28)
Ep=(Ecm/ncperm).*10.^-1
EIp1=(Ea.*Iyy)+(Ep.*Ic)
EIp2=Ea.*Aa.*Ep.*Ac
EIp3=(Ea.*Aa)+(Ep.*Ac)
EIp4=a.^2
EIp=(EIp1+(EIp2/EIp3).*EIp4).*10.^-4
%EIs - Shrinkage Effective Flexural Stiffness%
ncshrink=1+(1.1.*phi1)
Es=(Ecm/ncshrink).*10.^-1
EIs1=(Ea.*Iyy)+(Es.*Ic)
EIs2=Ea.*Aa.*Es.*Ac
EIs3=(Ea.*Aa)+(Es.*Ac)
EIs4=a.^2
EIs=(EIs1+(EIs2/EIs3).*EIs4).*10.^-4
%d1 - Deflection due to permanent loading%
ed1=Bayspace.*Gk.*10.^-3
d1=(5/384).*(((ed1.*(Beamspan.*10.^-3).^4))/EI0).*10.^3
%d2 - Deflection due to variable loading%
ed2=Bayspace.*Psi1.*Qk.*10.^-3
d2=(5/384).*(((ed2.*(Beamspan.*10.^-3).^4))/EI0).*10.^3
%d3 - Deflection due to creep%
ed3=Bayspace.*(Gk+(Psi2.*Qk)).*10.^-3
d3=((5/384).*(((ed3.*(Beamspan.*10.^-3).^4))/EIp).*10.^3)-((5/384).*(((ed3.*(Beamspan.*10.^-3).^4))/EI0).*10.^3)
%d4 - Deflection due to shrinkage%
Ncs=epsilonsc.*Es.*Ac
ac=(Ea.*Aa)/((Ea.*Aa)+(Es.*Ac)).*a
Mcs=Ncs.*(ac/100)
d4=(1/8).*((Mcs.*(Beamspan.*10^-3).^2)/EIs).*10.^3
%dTOTAL - total deflection due to total load%
dTOTAL=d1+d2+d3+d4
if dTOTAL<Beamspan/250
    "Pass"
else dTOTAL>Beamspan/250
    "Fail"
end
%
% Part 4, Calculation of Embodied Energy Content%
%
% Part 4a, Calculation of Component Mass%
% Massa - Steel Section%
Massa=mass.*Beamspan.*10.^-3
% Masssc - Shear Connectors%
AshankDIA=(pi.*(SCDIA.*10.^-3).^2)/4
AheadDIA=(pi.*(SHDIA.*10.^-3).^2)/4
Vshank=(AshankDIA.*Lshank).*10.^-3
Vhead=(AheadDIA.*Lhead).*10.^-3
Vsc=Vshank+Vhead
Kgsc=Vsc.*Densitysc
Masssc=Kgsc.*Noconnectors
% Massps - Profiled Sheet%
Massps=Floorarea.*Densityps
% Massc - Concrete Slab%
Averagehc=(hc+(hc-hp))/2.*10.^-3
Vconc=Floorarea.*Averagehc
Massc=Vconc.*Densityconc
% Massr - Reinforcing Steel Mesh%
Rebarsheets=Floorarea/Rebarsheetarea
Massr=Rebarsheets.*Densityr
%
%Part 4b, Calculation of Component Embodied Energy Content EEi%
EcontA=Massa.*EfactorA
EcontSC=Masssc.*EfactorSC
EcontPS=Massps.*EfactorPS
EcontC=Massc.*EfactorC
EcontR=Massr.*EfactorR
%
%Part 4c, Total Embodied Energy Content%
EEi=EcontA+EcontSC+EcontPS+EcontC+EcontR
