function MRd = Partialshear_Bending_Resist(MplaRD, MplRD, eta)
MRd=MplaRD+(MplRD-MplaRD).*eta;
end