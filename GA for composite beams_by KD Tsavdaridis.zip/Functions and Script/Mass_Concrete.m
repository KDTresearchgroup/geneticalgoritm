function Massc = Mass_Concrete(Vconc, Densityconc)
Massc=Vconc.*Densityconc;
end