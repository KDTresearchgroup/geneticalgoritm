function d2 = Variable_Deflection(ed2, Beamspan, EI0)
d2=(5/384).*(((ed2.*(Beamspan.*10.^-3).^4))/EI0).*10.^3;
end