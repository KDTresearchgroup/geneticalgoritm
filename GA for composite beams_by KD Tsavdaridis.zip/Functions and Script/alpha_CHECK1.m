function alphaCHECK1 = alpha_CHECK1(hsc, SCDIA)
alphaCHECK1=hsc/SCDIA;
end