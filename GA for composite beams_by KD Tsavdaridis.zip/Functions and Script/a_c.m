function ac = a_c(Ea, Aa, Es, Ac, a)
ac=(Ea.*Aa)/((Ea.*Aa)+(Es.*Ac)).*a;
end