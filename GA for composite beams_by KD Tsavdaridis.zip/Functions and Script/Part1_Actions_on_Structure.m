%Part 1 - Actions on the Structure
clc
% Determination of Combined Actions upon Structure, Design Bending Moment
% and Design Shear Force
Fd1 = Combined_force(Gk, gammaG, Qk, gammaQ)
Floorarea = Floor_area(Beamspan, Bayspace)
Fd = Combined_action(Fd1, Floorarea)
MEd = Design_moment(Fd, Beamspan)
VEd = Design_shear(Fd)
