%%% Part 3 - SLS Design Check
h0=2.*hc;
%Short Term Effective Flexural Stiffness
Ic = Concrete_SMA(beff, hc);
Ac = Concrete_Area(beff, hc);
a = Concrete_Smalla(ha, hp, hc);
E0 = Short_E(Ecm, ncshort);
EI01=(Ea.*Iyy)+(E0.*Ic);
EI02=Ea.*Aa.*E0.*Ac;
EI03=(Ea.*Aa)+(E0.*Ac);
EI04=a.^2;
EI0 = Shortterm_Stiffness(EI01, EI02, EI03, EI04);
%Permanent Effective Flexural Stiffness
ncperm = nc_perm(phi28);
Ep = Permanent_E(Ecm, ncperm);
EIp1=(Ea.*Iyy)+(Ep.*Ic);
EIp2=Ea.*Aa.*Ep.*Ac;
EIp3=(Ea.*Aa)+(Ep.*Ac);
EIp4=a.^2;
EIp = Permanent_Stiffness(EIp1, EIp2, EIp3, EIp4);
% Shrinkage Effective Flexural Stiffness
ncshrink = nc_shrinkage(phi1);
Es = Shrinkage_E(Ecm, ncshrink);
EIs1=(Ea.*Iyy)+(Es.*Ic);
EIs2=Ea.*Aa.*Es.*Ac;
EIs3=(Ea.*Aa)+(Es.*Ac);
EIs4=a.^2;
EIs = Shrinkage_Stiffness(EIs1, EIs2, EIs3, EIs4);
% Deflection Due to Permanent Loading
ed1 = ed_1(Bayspace, Gk);
d1 = Permanent_Deflection(ed1, Beamspan, EI0);
% Deflection Due to Variable Loading
ed2 = ed_2(Bayspace, Psi1, Qk);
d2 = Variable_Deflection(ed2, Beamspan, EI0);
% Deflection Due to Creep
ed3 = ed_3(Gk, Psi2, Bayspace, Qk);
d3 = Creep_Deflection(ed3, Beamspan, EIp, EI0);
% Deflection Due to Shrinkage
Ncs = nc_shrinkagestress(epsilonsc, Es, Ac);
ac = a_c(Ea, Aa, Es, Ac, a);
Mcs = M_cs(Ncs, ac);
d4 = Shrinkage_Deflection(Mcs, Beamspan, EIs);
%Total Deflection
dTOTAL = Total_Deflection(d1, d2, d3, d4)
if dTOTAL<Beamspan/250
    "Pass"
else dTOTAL>Beamspan/250
    "Fail"
end