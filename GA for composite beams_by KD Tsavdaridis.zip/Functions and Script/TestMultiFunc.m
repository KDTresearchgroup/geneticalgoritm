function y = TestMultiFunc (b, c)
y = a*d
a = b+c
d = c-b

end
