function Massa = Mass_Steel(Mass, Beamspan)
Massa=Mass.*Beamspan.*10.^-3;
end