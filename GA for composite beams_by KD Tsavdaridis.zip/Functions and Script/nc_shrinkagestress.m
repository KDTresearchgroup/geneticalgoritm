function Ncs = nc_shrinkagestress(epsilonsc, Es, Ac)
Ncs=epsilonsc.*Es.*Ac;
end