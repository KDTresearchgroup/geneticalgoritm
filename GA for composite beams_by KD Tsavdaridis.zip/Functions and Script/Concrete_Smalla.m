function a = Concrete_Smalla(ha, hp, hc)
a=((ha/2)+hp+(hc/2)).*10.^-1;
end