% main function - optimisation
FitFcn = @(Y A D)TestMultiFuncVari(x)
nvars = 2
lb = [5, 2]
ub = [76, 87]
[x, Fval] = gamultiobj(FitFcn,nvars,[],[],[],[],lb,ub);
x
Fval