function alphaCHECK2 = alpha_CHECK2(hsc, SCDIA)
alphaCHECK2=0.2.*((hsc/SCDIA)+1);
end