function EcontR = Energy_Rebar(Massr, EfactorR)
EcontR=Massr.*EfactorR;
end