function dTOTAL = Total_Deflection(d1, d2, d3, d4)
dTOTAL=d1+d2+d3+d4;
end