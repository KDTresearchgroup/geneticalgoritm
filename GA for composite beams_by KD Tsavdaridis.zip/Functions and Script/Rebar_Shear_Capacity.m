function VEdREBAR = Rebar_Shear_Capacity(Rq, hc, hp, Beamspan)
VEdREBAR=(Rq.*1000)/(2.*(hc-hp).*(Beamspan/2));
end